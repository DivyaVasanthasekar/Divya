package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClassNew;
import pages.LoginNew;

public class EditLeadTestCase extends BaseClassNew {

	@BeforeTest
	public void setFile() {
		excelfile = "dataForEditLead";
		name = "EditLead";
		description = "Report for EditLead Testcase";
		author= "Divya";
		category = "smoke";

	}
	
	@Test(dataProvider = "fetchData")
	public void runEditLead(String mobile, String cName) throws InterruptedException, IOException {
		
		new LoginNew(driver,node,test)
		.enterUserName()
		.enterPassword()
		.clickLogin()
		.clickCRMSFA()
		.clickLeads()
		.clickFindLead()
		.clickPhoneTab()
		.enterPhoneNumber(mobile)
		.clickFindLead()
		.clickfirstLeadID()
		.clickEditTab()
		.updateCoampanyName(cName)
		.clickUpdateButton()
		.verifyCompanyName();
		
		
		

	}
}
