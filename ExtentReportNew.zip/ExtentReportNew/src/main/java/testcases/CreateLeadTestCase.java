package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClassNew;
import pages.LoginNew;

public class CreateLeadTestCase extends BaseClassNew{
	
	@BeforeTest
	public void setFile() {
		excelfile = "dataForCreateLead";
		name = "CreateLead";
		description = "Report for CreateLead Testcase";
		author= "Divya";
		category = "smoke";
	}
	
	@Test(dataProvider = "fetchData")
	public void runCreateLead(String cName, String fName,String lName) throws IOException {
		
		new LoginNew(driver,node,test)
		.enterUserName()
		.enterPassword()
		.clickLogin()
		.clickCRMSFA()
		.clickLeads()
		.clickCreateLead()
		.enterCompanyName(cName)
		.enterFirstName(fName)
		.enterLastName(lName)
		.clickCreateLead()
		.verifyFirstName();

	}

}
