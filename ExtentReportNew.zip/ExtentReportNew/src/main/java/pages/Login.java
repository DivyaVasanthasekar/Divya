package pages;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;

import base.BaseClassNew;

public class Login extends BaseClassNew {

	
	public Login(FirefoxDriver driver, ExtentTest node, ExtentTest test) {

		this.driver = driver;
		this.node = node;
		this.test = test;
	}

	public LoginNew enterUserName() throws IOException {

		try {
			driver.findElementById("username").sendKeys("demoCSR");
			reportStep("username entered successfully","pass");
		}
		catch(Exception e) {
			System.out.println(e);
			reportStep("username not entered successfull","fail");
					}

		return this;
	}

	public LoginNew enterPassword() throws IOException {

		try {
			driver.findElementById("password").sendKeys("crmsfa");
			reportStep("password entered successfully","pass");
		}
		catch(Exception e) {
			System.out.println(e);
		reportStep("password not entered successfully","fail");
		}

		return this;
	}

	public HomeNew clickLogin() throws IOException {

		try {
			driver.findElementByClassName("decorativeSubmit").click();
		reportStep("clicked login button successfully","pass");
		}
		catch(Exception e) {
			System.out.println(e);
			reportStep("login button didnt clicked","fail");
		}
		return new HomeNew(driver,node,test);
	}

}
