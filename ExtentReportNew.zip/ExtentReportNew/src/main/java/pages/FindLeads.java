package pages;

import java.io.IOException;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.aventstack.extentreports.ExtentTest;

import base.BaseClassNew;

public class FindLeads extends BaseClassNew {

	public FindLeads(FirefoxDriver driver, ExtentTest node, ExtentTest test) {

		this.driver = driver;
		this.node = node;
		this.test = test;
	}

	public FindLeadsNew clickPhoneTab() throws IOException {

		try {
			driver.findElementByXPath("//span[text()='Phone']").click();
			reportStep("Phone tab clicked","pass");
		} catch (Exception e) {
			System.out.println(e);
			reportStep("Phone tab not clicked","fail");
		}


		return this;

	}

	public FindLeadsNew enterPhoneNumber(String mobile) throws IOException {
		try {
			driver.findElementByXPath("//input[@name='phoneNumber']").sendKeys(mobile);
			reportStep("PhoneNumber entered successfully","pass");
		} catch (Exception e) {
			System.out.println(e);
			reportStep("PhoneNumber not entered successfully","fail");
		}



		return this;
	}

	public FindLeadsNew clickFindLead() throws InterruptedException, IOException {

		try {
			driver.findElementByXPath("//button[text()='Find Leads']").click();

			Thread.sleep(2000); 
			reportStep("clicked findlead successfully","pass");
		} 
		catch (Exception e) {
			System.out.println(e);
			reportStep("Not clicked findlead ","fail");
		}

		return this;

	}


	public ViewLeadNew clickfirstLeadID() throws IOException {

		try {
			driver.findElementByXPath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a").click();
			reportStep("clicked firstlead successfully","pass");

		} catch (Exception e) {
			System.out.println(e);
			reportStep("not clicked firstlead ","fail");
		}


		return new ViewLeadNew(driver,node,test);
	}


}
