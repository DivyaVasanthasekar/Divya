package pages;

import java.io.IOException;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.aventstack.extentreports.ExtentTest;

import base.BaseClassNew;

public class ViewLead extends BaseClassNew{

	public ViewLead(FirefoxDriver driver, ExtentTest node, ExtentTest test) {

		this.driver = driver;
		this.node = node;
		this.test = test;

	}

	public void verifyFirstName() throws IOException {

		try {
			String text = driver.findElementById("viewLead_firstName_sp").getText();
			System.out.println("Created lead for" + text);
			reportStep("verified first name successfully","pass");
		} catch (Exception e) {
			System.out.println(e);
			reportStep(" not verified first name ","fail");
		}
		

	

		//return this;
	}

	public ViewLeadNew verifyCompanyName() throws IOException {

		try {

			String text = driver.findElementById("viewLead_companyName_sp").getText();

			System.out.println("Updated company name is" + text);
			reportStep("verified company name successfully","pass");

		} catch (Exception e) {
			System.out.println(e);
			reportStep(" not verified company name ","fail");
		}



		return this;

	}

	public EditLeadNew clickEditTab() throws IOException {

		try {
			driver.findElementByLinkText("Edit").click();
			reportStep(" clicked edittab successfully ","pass");

		} catch (Exception e) {
			System.out.println(e);
			reportStep(" not clicked edittab ","fail");
		}


		return new EditLeadNew(driver,node,test);

	}



}
