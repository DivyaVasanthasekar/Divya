package pages;

import java.io.IOException;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.aventstack.extentreports.ExtentTest;

import base.BaseClassNew;

public class Home extends BaseClassNew{

	public Home(FirefoxDriver driver, ExtentTest node, ExtentTest test) {

		this.driver = driver;
		this.node = node;
		this.test = test;
	}

	public MyHomeNew clickCRMSFA() throws IOException {

		try {

			driver.findElementByLinkText("CRM/SFA").click();
			reportStep("CRMSFA clicked successfully","pass");
		}
		catch (Exception e) {
			System.out.println(e);
			reportStep("CRMSFA not clicked successfully","fail");
		}


		return new MyHomeNew(driver , node, test);

	}

	public LoginNew clickLogout() throws IOException {

		try {
			driver.findElementByClassName("decorativeSubmit").click();
			reportStep("clicked logout successfully","pass");
		} catch (Exception e) {
			System.out.println(e);
			reportStep(" not clicked logout button","fail");
		}


		return new LoginNew(driver, node, test);
	}

}
