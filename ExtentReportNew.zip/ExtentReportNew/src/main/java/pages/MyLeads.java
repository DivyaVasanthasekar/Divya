package pages;

import java.io.IOException;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.aventstack.extentreports.ExtentTest;

import base.BaseClassNew;

public class MyLeads extends BaseClassNew {
	
public MyLeads(FirefoxDriver driver, ExtentTest node, ExtentTest test) {
		
		this.driver = driver;
		this.test = test;
		this.node = node;
	}
	
	public CreateLeadNew clickCreateLead() throws IOException {
		try {
			driver.findElementByLinkText("Create Lead").click();
			reportStep("clicked createlead button successfully","pass");
			
		} catch (Exception e) {
		System.out.println(e);
		reportStep("not clicked createlead button successfully","fail");
		}
	
		
		return new CreateLeadNew(driver,node,test);
	}
	
	public FindLeadsNew clickFindLead() throws IOException {
		
		try {
			driver.findElementByLinkText("Find Leads").click();
			reportStep("clicked findlead button successfully","pass");
			
		} catch (Exception e) {
			System.out.println(e);
			reportStep("not clicked findlead button successfully","fail");
		}
		
		
		return new FindLeadsNew(driver,node,test);

	}

}
