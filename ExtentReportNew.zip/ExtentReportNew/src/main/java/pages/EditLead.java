package pages;

import java.io.IOException;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.aventstack.extentreports.ExtentTest;

import base.BaseClassNew;

public class EditLead extends BaseClassNew {
	
	public EditLead(FirefoxDriver driver, ExtentTest node, ExtentTest test) {
		
		this.driver = driver;
		this.test = test;
		this.node = node;
	}

	public EditLeadNew updateCoampanyName(String cName) throws IOException {
		
		try {
		driver.findElementById("updateLeadForm_companyName").clear();
		
		driver.findElementById("updateLeadForm_companyName").sendKeys(cName);
		reportStep("company name " +cName+"updated sucessfully ","pass");
		}
		catch(Exception e) {
			System.out.println(e);
			reportStep("company name " +cName+"not updated sucessfully ","fail");
		}
		return this;

	}
	
	public ViewLeadNew clickUpdateButton() throws IOException {
		try {
			driver.findElementByName("submitButton").click();
			reportStep("update button clicked succesfully ","pass");
		} 
		catch (Exception e) {
			System.out.println(e);
			reportStep("update button not clicked succesfully ","fail");
		}
	
		
		return new ViewLeadNew(driver,node,test);
	}
	
}
	