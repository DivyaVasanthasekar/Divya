package pages;

import java.io.IOException;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.aventstack.extentreports.ExtentTest;

import base.BaseClassNew;

public class CreateLead extends BaseClassNew{
	
	public CreateLead(FirefoxDriver driver, ExtentTest test,ExtentTest node) {
		
		this.driver = driver;
		this.node = node;
		this.test = test;
	}
	
	public CreateLeadNew enterFirstName(String fName) throws IOException {
	
		try {
		driver.findElementById("createLeadForm_firstName").sendKeys(fName);
		reportStep("first name  " +fName+"entered successfully","pass");
		}
		catch(Exception e) {
			System.out.println(e);
			reportStep("first name  " +fName+ "not entered successfully","fail");	
		}
		return this;
	
	}
	
	public CreateLeadNew enterLastName(String lName) throws IOException {
		try {
		driver.findElementById("createLeadForm_lastName").sendKeys(lName);
		reportStep("last name " +lName+ "entered successfully","pass");
		}
		catch(Exception e) {
			System.out.println(e);
			reportStep("last name " +lName+" not entered successfully","fail");
		}
		return this;
	}
	
	public CreateLeadNew enterCompanyName(String cName) throws IOException {
		try {
		driver.findElementById("createLeadForm_companyName").sendKeys(cName);
		reportStep("company name " +cName+ "entered successfully","pass");
		}
		catch(Exception e) {
			System.out.println(e);
			reportStep("company name " +cName+ " not entered successfully","fail");
		}
		return this;
	}
	
	public ViewLeadNew clickCreateLead() throws IOException {
		
		try {
		driver.findElementByName("submitButton").click();
		reportStep("clicked create lead successfully","pass");
		}
		catch(Exception e) {
			System.out.println(e);
			reportStep("create lead button not clicked ","fail");
		}
		return new ViewLeadNew(driver,node,test);
	}

}
