package pages;

import java.io.IOException;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.aventstack.extentreports.ExtentTest;

import base.BaseClassNew;

public class MyHome extends BaseClassNew {
	
public MyHome(FirefoxDriver driver, ExtentTest node, ExtentTest test) {
		
		this.driver = driver;
		this.node = node;
		this.test = test;
	}
	
	public MyLeadsNew clickLeads() throws IOException {
	try {
		driver.findElementByLinkText("Leads").click();
		reportStep("clicked leads button successfully","pass");
		
	} catch (Exception e) {
		System.out.println(e);
		reportStep("not clicked leads button successfully","fail");
	}	
		
		
		return new MyLeadsNew(driver,node,test);
	}

}
