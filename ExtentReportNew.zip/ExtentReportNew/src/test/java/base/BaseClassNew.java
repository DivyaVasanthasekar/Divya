package base;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import cucumber.api.testng.AbstractTestNGCucumberTests;
import utils.readExcel;

public class BaseClassNew extends AbstractTestNGCucumberTests {

	public static FirefoxDriver driver;
	public String excelfile,name , description,author,category;
	public static ExtentHtmlReporter reporter;
	public static ExtentReports extent;
	public  static ExtentTest test,node;

	
	public long takeSnap() throws IOException {
	
		long number = (long) Math.floor(Math.random()*900000000L + 100000000);
		File source = driver.getScreenshotAs(OutputType.FILE);
		File target = new File("./Screenshots/img"+number+".png");
		FileUtils.copyFile(source, target);
		return number;
	}
	
	public void reportStep(String msg,String status) throws IOException {
		
		if(status.equalsIgnoreCase("pass")) {
			node.pass(msg, MediaEntityBuilder.createScreenCaptureFromPath(".././Screenshots/img"+takeSnap()+".png").build());
		}
		
		else if(status.equalsIgnoreCase("fail")){
			node.fail(msg,MediaEntityBuilder.createScreenCaptureFromPath(".././Screenshots/img"+takeSnap()+".png").build());
		}

	}

	@BeforeSuite
	public void extentReport() {

		//create blank report file location
		reporter = new ExtentHtmlReporter("./reports/testCaseResult.html");
		//to have history
		reporter.setAppendExisting(true);

		//create actual report
		extent = new ExtentReports();

		//attach actual report to the empty report
		extent.attachReporter(reporter);

	}


	@BeforeClass
	public void extentTest() {

		test = extent.createTest(name, description);
		test.assignAuthor(author);
		test.assignCategory(category);

	}
	

	@BeforeMethod
	public void preCondition() throws InterruptedException {

		node = test.createNode(name);
		//webdriver location
		System.setProperty("webdriver.gecko.driver","./drivers/geckodriver_32 bit.exe" );

		//Creating class for chromedriver
		driver = new FirefoxDriver();

		//got to url http://leafground.com/pages/Button.html
		driver.get("http://leaftaps.com/opentaps/control/main");

		//maximize the window
		driver.manage().window().maximize();

		//applying implicit wait
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);


	}

	@AfterMethod
	public void postCondition() {

		driver.close();

	}

//	@DataProvider(name = "fetchData")
	//public String[][] sendData() throws IOException {

	//	return readExcel.readExcel(excelfile);

	//}

	@AfterSuite
	public void flushMethod() {
		
		extent.flush();

	}
	
}
