package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.Login;

public class CreateLeadTestCase extends BaseClass{
	
	@BeforeTest
	public void setFile() {
		excelfile = "dataForCreateLead";
		name = "CreateLead";
		description = "Report for CreateLead Testcase";
		author= "Divya";
		category = "smoke";
	}
	
	@Test(dataProvider = "fetchData")
	public void runCreateLead(String cName, String fName,String lName) throws IOException {
		
		new Login(driver,node,test)
		.enterUserName()
		.enterPassword()
		.clickLogin()
		.clickCRMSFA()
		.clickLeads()
		.clickCreateLead()
		.enterCompanyName(cName)
		.enterFirstName(fName)
		.enterLastName(lName)
		.clickCreateLead()
		.verifyFirstName();

	}

}
