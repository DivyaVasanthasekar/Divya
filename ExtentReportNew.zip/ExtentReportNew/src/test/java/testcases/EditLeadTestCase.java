package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.Login;

public class EditLeadTestCase extends BaseClass {

	@BeforeTest
	public void setFile() {
		excelfile = "dataForEditLead";
		name = "EditLead";
		description = "Report for EditLead Testcase";
		author= "Divya";
		category = "smoke";

	}
	
	@Test(dataProvider = "fetchData")
	public void runEditLead(String mobile, String cName) throws InterruptedException, IOException {
		
		new Login(driver,node,test)
		.enterUserName()
		.enterPassword()
		.clickLogin()
		.clickCRMSFA()
		.clickLeads()
		.clickFindLead()
		.clickPhoneTab()
		.enterPhoneNumber(mobile)
		.clickFindLead()
		.clickfirstLeadID()
		.clickEditTab()
		.updateCoampanyName(cName)
		.clickUpdateButton()
		.verifyCompanyName();
		
		
		

	}
}
