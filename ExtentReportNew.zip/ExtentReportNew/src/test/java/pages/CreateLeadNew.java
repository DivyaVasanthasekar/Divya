package pages;

import java.io.IOException;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.aventstack.extentreports.ExtentTest;

import base.BaseClass;
import cucumber.api.java.en.*;

public class CreateLeadNew extends BaseClass{
	
	
	
	@And("enter first name as (.*)")
	public CreateLeadNew enterFirstName(String fName) throws IOException {
	
		try {
		driver.findElementById("createLeadForm_firstName").sendKeys(fName);
		reportStep("first name  " +fName+"entered successfully","pass");
		}
		catch(Exception e) {
			System.out.println(e);
			reportStep("first name  " +fName+ "not entered successfully","fail");	
		}
		return this;
	
	}
	
	@And("enter last name as (.*)")
	public CreateLeadNew enterLastName(String lName) throws IOException {
		try {
		driver.findElementById("createLeadForm_lastName").sendKeys(lName);
		reportStep("last name " +lName+ "entered successfully","pass");
		}
		catch(Exception e) {
			System.out.println(e);
			reportStep("last name " +lName+" not entered successfully","fail");
		}
		return this;
	}
	
	@Given("enter companyname as (.*)")
	public CreateLeadNew enterCompanyName(String cName) throws IOException {
		try {
		driver.findElementById("createLeadForm_companyName").sendKeys(cName);
		reportStep("company name " +cName+ "entered successfully","pass");
		}
		catch(Exception e) {
			System.out.println(e);
			reportStep("company name " +cName+ " not entered successfully","fail");
		}
		return this;
	}
	
	@When("Submit the create lead button in bottom")
	public ViewLeadNew clickCreateLead() throws IOException {
		
		try {
		driver.findElementByName("submitButton").click();
		reportStep("clicked create lead successfully","pass");
		}
		catch(Exception e) {
			System.out.println(e);
			reportStep("create lead button not clicked ","fail");
		}
		return new ViewLeadNew();
	}

}
