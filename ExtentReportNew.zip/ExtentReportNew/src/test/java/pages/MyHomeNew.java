package pages;

import java.io.IOException;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.aventstack.extentreports.ExtentTest;

import base.BaseClass;

public class MyHomeNew extends BaseClass {
	

	
	public MyLeadsNew clickLeads() throws IOException {
	try {
		driver.findElementByLinkText("Leads").click();
		reportStep("clicked leads button successfully","pass");
		
	} catch (Exception e) {
		System.out.println(e);
		reportStep("not clicked leads button successfully","fail");
	}	
		
		
		return new MyLeadsNew();
	}

}
