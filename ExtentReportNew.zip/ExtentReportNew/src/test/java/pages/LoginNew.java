package pages;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;

import base.BaseClass;
import cucumber.api.java.en.*;

public class LoginNew extends BaseClass {

	
	
	@Given("Enter the username as (.*)")
	public LoginNew enterUserName(String uName) throws IOException {

		try {
			driver.findElementById("username").sendKeys(uName);
			reportStep("username " +uName+ "entered successfully","pass");
		}
		catch(Exception e) {
			System.out.println(e);
			reportStep("username not entered successfull","fail");
					}

		return this;
	}

	@And("Enter the password as (.*)")
	public LoginNew enterPassword(String pName) throws IOException {

		try {
			driver.findElementById("password").sendKeys(pName);
			reportStep("password " +pName+ "entered successfully","pass");
		}
		catch(Exception e) {
			System.out.println(e);
		reportStep("password not entered successfully","fail");
		}

		return this;
	}

	@When("Click on login button")
	public HomeNew clickLogin() throws IOException {

		try {
			driver.findElementByClassName("decorativeSubmit").click();
		reportStep("clicked login button successfully","pass");
		}
		catch(Exception e) {
			System.out.println(e);
			reportStep("login button didnt clicked","fail");
		}
		return new HomeNew();
	}

}
