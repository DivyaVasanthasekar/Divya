package pages;

import java.io.IOException;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.aventstack.extentreports.ExtentTest;

import base.BaseClass;
import cucumber.api.java.en.*;

public class MyLeadsNew extends BaseClass {
	

	

	@And("Click on Create lead button")
	public CreateLeadNew clickCreateLead() throws IOException {
		try {
			driver.findElementByLinkText("Create Lead").click();
			reportStep("clicked createlead button successfully","pass");
			
		} catch (Exception e) {
		System.out.println(e);
		reportStep("not clicked createlead button successfully","fail");
		}
	
		
		return new CreateLeadNew();
	}
	
	public FindLeadsNew clickFindLead() throws IOException {
		
		try {
			driver.findElementByLinkText("Find Leads").click();
			reportStep("clicked findlead button successfully","pass");
			
		} catch (Exception e) {
			System.out.println(e);
			reportStep("not clicked findlead button successfully","fail");
		}
		
		
		return new FindLeadsNew();

	}

}
