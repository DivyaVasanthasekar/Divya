package Runner;

import org.testng.annotations.BeforeTest;

import base.BaseClassNew;
import cucumber.api.CucumberOptions;


@CucumberOptions(features = {"src/test/java/Feature/"},
								glue = "pages",
								monochrome = true,
								dryRun = true)
public class RunnerClass extends BaseClassNew{
	
	
	@BeforeTest
	public void setFile() {
		//excelfile = "dataForCreateLead";
		name = "CreateLead";
		description = "Report for CreateLead Testcase";
		author= "Divya";
		category = "smoke";
	}
	

}
